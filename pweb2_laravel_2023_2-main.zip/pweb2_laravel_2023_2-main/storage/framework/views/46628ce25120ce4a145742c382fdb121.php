<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulário Aluno</title>
</head>
<body>
    <h3>Formulário de Aluno</h3>
    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <?php
    if(!empty($aluno->id)){
        $route = route('aluno.update', $aluno->id);
    } else {
        $route = route('aluno.store');
    }
    ?>

    <form action="<?php echo e($route); ?>" method="post">
        <?php echo csrf_field(); ?> <!-- cria um hash de segurança -->

        <?php if(!empty($aluno->id)): ?>
            <?php echo method_field('PUT'); ?>;
        <?php endif; ?>

        <input type="hidden" name="id" value="<?php if(!empty($aluno->id)): ?><?php echo e($aluno->id); ?><?php elseif(!empty(old('id'))): ?><?php echo e(old('id')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>">
        <label for="">Nome</label><br>
        <input type="text" name="nome" value="<?php if(!empty($aluno->nome)): ?><?php echo e($aluno->nome); ?><?php elseif(!empty(old('nome'))): ?><?php echo e(old('nome')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>"><br><br>
        <label for="">Data Nascimento</label><br>
        <input type="text" name="data_nascimento" value="<?php if(!empty($aluno->data_nascimento)): ?><?php echo e($aluno->data_nascimento); ?><?php elseif(!empty(old('data_nascimento'))): ?><?php echo e(old('data_nascimento')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>"><br><br>
        <label for="">CPF</label><br>
        <input type="text" name="cpf" value=" <?php if(!empty($aluno->cpf)): ?><?php echo e($aluno->cpf); ?><?php echo e(old('cpf')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>"><br><br>
        <label for="">Email</label><br>
        <input type="email" name="email" value="<?php if(!empty($aluno->email)): ?><?php echo e($aluno->email); ?><?php elseif(!empty(old('email'))): ?><?php echo e(old('email')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>"><br><br>
        <label for="">Telefone</label><br>
        <input type="text" name="telefone" value="<?php if(!empty($aluno->telefone)): ?><?php echo e($aluno->telefone); ?><?php echo e(old('telefone')); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>"><br><br>

        <button type="submit">Salvar</button><br>
        <a href="<?php echo e(route('aluno.index')); ?>">Voltar</a>
    </form>
</body>
</html>

<?php /**PATH C:\laragon\www\pweb2_laravel_2023_2-main\resources\views/aluno/form.blade.php ENDPATH**/ ?>